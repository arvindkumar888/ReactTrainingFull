import {Contact} from './contact';
// Model  - POJO - JSON array - State of App

export const CONTACTS:Contact[] =[
{name:'Murthy', email:'murthy@gmail.com', phone:'2445678'},
{name:'Kavitha', email:'kavita@gmail.com', phone:'3435678'},
{name:'Rama', email:'rama@gmail.com', phone:'34353678'}
]
