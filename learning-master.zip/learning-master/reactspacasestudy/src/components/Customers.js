import React from 'react';
export const Customers= () => (
    <div>
    <h1>Customers Page</h1>
    <table border="1">
    <th>Customer Name</th>
    <th>Email</th>
    <th>City</th>
    <tr>
     <td>Kiran Kumar</td>
     <td>Kiran@gmail.com</td>
     <td>Hyderabad</td>
     </tr>
     <tr>
     <td>Lalitha</td>
     <td>lalitha@gmail.com</td>
     <td>Mumbai</td>
     </tr>
     <tr>
     <td>Ravinder</td>
     <td>ravi@gmail.com</td>
     <td>Chennai</td>
     </tr>
    </table>
    </div>
)
