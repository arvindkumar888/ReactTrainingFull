import React from 'react';

export class ProductInfo extends React.Component{
	render(){
		return(
			<div>
			 Latest product introduced  recently 
			</div>
		);
	}
}