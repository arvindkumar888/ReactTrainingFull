import React, { Component } from 'react';


export default class Footer extends Component {
  render() {
    return (
      <div className="bgblue ">
          <h4>Copyright reserved to D.S.R.Murthy</h4>
       </div>
    );
  }
}
